// firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";


function curs(){
  const aps =document.getElementById("especialidad");
  const curso =  document.getElementById("Curso").value;
  const ssas =  document.getElementById("Division");
    if (["3","4","5"].includes(curso)){ 
        aps.classList.remove("ocultar");
        ssas.classList.add("ocultar");
        }
    else if (["2","1"].includes(curso))
      { 
        ssas.classList.remove("ocultar");
        aps.classList.add("ocultar");
        }
}


const firebaseConfig = {
  apiKey: "AIzaSyBVN4p3dIqFyyzr-LXblMwMKFHqZSFkv3I",
  authDomain: "estdgpt.firebaseapp.com",
  projectId: "estdgpt",
  storageBucket: "estdgpt.firebasestorage.app",
  messagingSenderId: "18127279576",
  appId: "1:18127279576:web:c924635eb6eeb4e2f44ead"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);
window.curs = curs;